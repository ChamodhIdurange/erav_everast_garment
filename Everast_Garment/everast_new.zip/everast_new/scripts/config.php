<?php
$db_username 	= 'root';
$db_password 	= '';
$db_name 		= 'erav_everast';
$db_host 		= 'localhost';
?>
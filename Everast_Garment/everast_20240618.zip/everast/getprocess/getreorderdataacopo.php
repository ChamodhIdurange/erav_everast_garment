<?php
require_once('../connection/db.php');

$locationID = $_POST['locationID'];


?>
<div class="row">
    

</div>

<script>

</script>